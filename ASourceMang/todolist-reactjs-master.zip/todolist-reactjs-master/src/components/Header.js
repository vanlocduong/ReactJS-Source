import React from 'react';

export class Header extends React.Component {
  render() {
    return(
      <div className="card-header">
        <h1>~Todo List~</h1>
      </div>
    )
  }
};

export default Header;