import uuid from 'react-uuid';

let items = [
  {
    id: uuid(),
    name: "Abc Lorem ipsum sit amet, consectetur adipisicing elit, consectetur adipisicing elit, consectetur adipisicing elit.",
    level: 0
  },
  {
    id: uuid(),
    name: "Def Lorem ipsum sit amet, consectetur adipisicing elit, consectetur adipisicing elit, consectetur adipisicing elit.",
    level: 1
  },
  {
    id: uuid(),
    name: "Ghi Lorem ipsum sit amet, consectetur adipisicing elit, consectetur adipisicing elit, consectetur adipisicing elit.",
    level: 2
  },
  {
    id: uuid(),
    name: "Jkl Lorem ipsum sit amet, consectetur adipisicing elit, consectetur adipisicing elit, consectetur adipisicing elit.",
    level: 1
  },
  {
    id: uuid(),
    name: "Mno Lorem ipsum sit amet, consectetur adipisicing elit, consectetur adipisicing elit, consectetur adipisicing elit.",
    level: 0
  }
];

export default items;