import * as types from '../constants/ActionTypes';

const toggleShowHistory = () => ({
  type: types.TOGGLE_SHOW_HISTORY,
});

export default toggleShowHistory;
