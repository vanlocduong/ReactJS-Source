export const MOBILE_WIDTH = 320;
export const TABLET_WIDTH = 736;
